### Documents

All the documents of zimg are in this page:  
[Documents of zimg](http://zimg.buaa.us/documents/)  